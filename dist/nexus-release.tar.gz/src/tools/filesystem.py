"""
Filesystem tools for NEXUS agents.

Provides read, write, and directory listing capabilities as LangChain tools
so agents can interact with the local filesystem in a structured way.
"""

from pathlib import Path

from langchain_core.tools import tool


@tool
def read_file(path: str) -> str:
    """Read the contents of a file.

    Args:
        path: Path to the file to read

    Returns:
        File contents as string
    """
    try:
        with open(path) as f:
            return f.read()
    except FileNotFoundError:
        return f"File not found: {path}"
    except Exception as e:
        return f"Error reading file: {e}"


@tool
def write_file(path: str, content: str) -> str:
    """Write content to a file (creates or overwrites).

    Args:
        path: Path to the file to write
        content: Content to write

    Returns:
        Success message with file path
    """
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            f.write(content)
        return f"Wrote {len(content)} bytes to {path}"
    except Exception as e:
        return f"Error writing file: {e}"


@tool
def list_directory(path: str = ".") -> str:
    """List contents of a directory.

    Args:
        path: Directory path (default: current directory)

    Returns:
        Directory listing
    """
    try:
        entries = sorted(Path(path).iterdir())
        lines = [f"  {'[DIR]' if e.is_dir() else '[FILE]'} {e.name}" for e in entries]
        return f"Directory: {path}\n" + "\n".join(lines)
    except Exception as e:
        return f"Error listing directory: {e}"
