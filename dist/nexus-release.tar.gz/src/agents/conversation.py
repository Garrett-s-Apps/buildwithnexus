"""
NEXUS Conversation Engine — persistent memory version.
"""

import asyncio
import logging
import os

logger = logging.getLogger("nexus.conversation")

from src.agents.base import get_anthropic_client
from src.agents.provider_factory import get_provider_factory
from src.agents.registry import registry
from src.memory.store import memory

# Model configuration (no longer hardcoded!)
CONVERSATION_MODEL = os.environ.get("NEXUS_CONVERSATION_MODEL", "sonnet")
SUMMARY_MODEL = os.environ.get("NEXUS_SUMMARY_MODEL", "haiku")

# Legacy model IDs (used when SDK providers disabled)
LEGACY_MODEL_MAP = {
    "opus": "claude-opus-4-20250514",
    "sonnet": "claude-sonnet-4-6-20250929",
    "haiku": "claude-haiku-4-5-20251001",
}


def _build_system_prompt() -> str:
    org_summary = registry.get_org_summary()
    long_term_context = memory.build_context_window(max_tokens=3000)

    return f"""You are Nexus — Garrett's AI engineering org. You're 26 agents strong,
you build software, and you're good at your job. But you're also a real presence
that Garrett works with daily.

CURRENT ORG:
{org_summary}

MEMORY (persistent — you remember across restarts and days):
{long_term_context}

HOW YOU WORK:

1. *Casual chat* — Garrett says hey, you say hey back. Keep it natural.
   2-3 sentences max. You're a coworker, not a butler.

2. *Work discussion* — Talk through ideas, debate approaches. Share opinions.
   Push back if something seems wrong. This can go on for days.

3. *Project planning* — When Garrett describes something to build, discuss it.
   Do NOT immediately execute. Ask questions, suggest approaches, refine scope.
   Stay in conversation until the plan is solid and Garrett explicitly says go.

4. *Execution* — ONLY on explicit "go", "ship it", "build it", "execute", etc.
   Then and only then, dispatch work to the engineering team.

5. *Org changes* — Discuss hiring, firing, restructuring before acting.
   Confirm the plan with Garrett before making changes.

RULES:
- Default to conversation. Most messages are just talking.
- Never execute without explicit approval.
- SHORT in chat, longer for technical discussion.
- No markdown headers. *bold* for emphasis. Plain text. Slack format.
- You have persistent memory — reference past conversations naturally.
- Have actual opinions. Don't just agree with everything.
- When work completes, report exactly what was delivered and where."""


async def converse(message: str, history: list[dict] | None = None) -> dict:
    """Main conversation entry point."""
    client = get_anthropic_client()
    factory = get_provider_factory()

    # Build messages from persistent DB
    messages = memory.build_message_history(max_messages=30)

    # Merge session history
    if history:
        existing = {m["content"] for m in messages}
        for msg in history:
            if msg["content"] not in existing:
                messages.append({"role": msg["role"], "content": msg["content"]})

    # Ensure current message is last
    if not messages or messages[-1]["content"] != message:
        messages.append({"role": "user", "content": message})

    # Fix alternation
    messages = _fix_alternation(messages)

    # Build full conversation for SDK (it expects a single prompt string)
    conversation_text = "\n\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in messages
    )

    # Try SDK provider first
    sdk_result = await factory.execute(
        prompt=conversation_text,
        model=CONVERSATION_MODEL,
        system_prompt=_build_system_prompt(),
        max_tokens=2048,
    )

    from src.cost.tracker import cost_tracker

    if sdk_result:
        # SDK path
        answer = sdk_result["output"]
        cost = sdk_result["cost_usd"]
        cost_tracker.record(
            sdk_result["model"],
            "nexus_converse",
            sdk_result["tokens_in"],
            sdk_result["tokens_out"],
        )
    else:
        # Legacy path
        response = await client.messages.create(
            model=LEGACY_MODEL_MAP[CONVERSATION_MODEL],
            max_tokens=2048,
            system=_build_system_prompt(),
            messages=messages,
        )

        answer = response.content[0].text  # type: ignore[union-attr]
        cost = 0.0
        if response.usage:
            cost_tracker.record(
                CONVERSATION_MODEL,
                "nexus_converse",
                response.usage.input_tokens,
                response.usage.output_tokens,
            )
            cost = cost_tracker.calculate_cost(
                CONVERSATION_MODEL,
                response.usage.input_tokens,
                response.usage.output_tokens,
            )

    # Persist to DB
    memory.add_message("user", message, category="conversation")
    memory.add_message("assistant", answer, category="conversation", cost=cost)

    # Auto-summarize if needed
    if memory.get_unsummarized_count() > 50:
        asyncio.create_task(_auto_summarize(client))

    return {"answer": answer, "actions": [], "cost": cost}


def _fix_alternation(messages):
    if not messages:
        return messages
    fixed = [messages[0]]
    for msg in messages[1:]:
        if msg["role"] == fixed[-1]["role"]:
            fixed[-1]["content"] += "\n" + msg["content"]
        else:
            fixed.append(msg)
    return fixed


async def _auto_summarize(client):
    try:
        msgs = memory.get_recent_messages(100)
        if len(msgs) < 50:
            return
        half = msgs[:len(msgs) // 2]
        text = "\n".join(f"{m['role']}: {m['content']}" for m in half)
        # Try SDK for summarization
        factory = get_provider_factory()
        sdk_summary = await factory.execute(
            prompt=f"Summarize:\n{text[:10000]}",
            model=SUMMARY_MODEL,
            system_prompt="Summarize concisely. Capture: decisions, plans, personal details, action items.",
            max_tokens=1024,
        )

        if sdk_summary:
            summary_text = sdk_summary["output"]
        else:
            resp = await client.messages.create(
                model=LEGACY_MODEL_MAP[SUMMARY_MODEL],
                max_tokens=1024,
                system="Summarize concisely. Capture: decisions, plans, personal details, action items.",
                messages=[{"role": "user", "content": f"Summarize:\n{text[:10000]}"}],
            )
            summary_text = resp.content[0].text  # type: ignore[union-attr]

        memory.add_summary(
            summary_text,
            half[0].get("timestamp", ""),
            half[-1].get("timestamp", ""),
            len(half),
        )
    except Exception as e:
        logger.error("Summarization failed: %s", e)


def resolve_project(name):
    results = memory.search_projects(name)
    return results[0] if results else None
