"""Disk-based filesystem backend for intermediate result storage."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from .backend import FilesystemBackend


class DiskBackend(FilesystemBackend):
    """Stores intermediate results as files under a root directory.

    File layout::

        root/
          <key>.txt        -- raw value
          <key>.meta.json  -- optional metadata
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _value_path(self, key: str) -> Path:
        # Sanitise key to avoid path traversal
        safe = key.replace("/", "__").replace("..", "__")
        return self.root / f"{safe}.txt"

    def _meta_path(self, key: str) -> Path:
        safe = key.replace("/", "__").replace("..", "__")
        return self.root / f"{safe}.meta.json"

    def write(self, key: str, value: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        path = self._value_path(key)
        path.write_text(value, encoding="utf-8")
        if metadata is not None:
            self._meta_path(key).write_text(json.dumps(metadata), encoding="utf-8")
        return str(path)

    def read(self, key: str) -> Optional[str]:
        path = self._value_path(key)
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    def list(self, prefix: str = "") -> list[str]:
        keys = []
        for p in self.root.glob("*.txt"):
            key = p.stem  # strip .txt
            if key.endswith(".meta"):
                continue
            if key.startswith(prefix.replace("/", "__")):
                keys.append(key)
        return sorted(keys)

    def delete(self, key: str) -> bool:
        path = self._value_path(key)
        if not path.exists():
            return False
        path.unlink()
        meta = self._meta_path(key)
        if meta.exists():
            meta.unlink()
        return True

    def clear(self) -> None:
        for p in self.root.glob("*.txt"):
            p.unlink(missing_ok=True)
        for p in self.root.glob("*.meta.json"):
            p.unlink(missing_ok=True)
