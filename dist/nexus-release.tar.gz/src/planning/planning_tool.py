from langchain_core.tools import tool
from typing import List

from .todo_manager import TodoManager


class WriteTodosTool:
    def __init__(self):
        self.manager = TodoManager()
        self.write_todos = self._create_write_todos_tool()

    def _create_write_todos_tool(self):
        manager = self.manager

        @tool
        def write_todos(todos: List[dict]) -> str:
            """Write or update the current plan as a todo list.

            Each todo should have: title (str), description (str).

            This tool makes the agent's plan persistent and inspectable.
            Call this at the start of complex tasks to decompose them.

            Example::

                write_todos([
                    {
                        "title": "Research user requirements",
                        "description": "Interview 5 users about feature needs"
                    },
                    {
                        "title": "Design architecture",
                        "description": "Sketch system design based on requirements"
                    },
                    {
                        "title": "Implement and test",
                        "description": "Code, unit tests, integration tests"
                    }
                ])
            """
            manager.todos.clear()  # Reset for new plan
            for todo in todos:
                manager.create(todo["title"], todo["description"])

            todo_list = manager.to_list()
            return "Created {} todos:\n".format(len(todo_list)) + "\n".join(
                ["- [{}] {}".format(t["status"], t["title"]) for t in todo_list]
            )

        return write_todos

    def mark_todo_done(self, todo_id: str) -> str:
        self.manager.update_status(todo_id, "done")
        return f"Marked todo {todo_id} as done"

    def get_plan(self) -> List[dict]:
        return self.manager.to_list()
