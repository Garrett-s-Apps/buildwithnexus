"""SQLite-based filesystem backend for intermediate result storage."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, Optional

from .backend import FilesystemBackend

_DDL = """
CREATE TABLE IF NOT EXISTS results (
    key      TEXT PRIMARY KEY,
    value    TEXT NOT NULL,
    metadata TEXT
);
"""


class SQLiteBackend(FilesystemBackend):
    """Stores intermediate results in a SQLite database.

    Suitable for concurrent access patterns and environments where
    a single-file database is preferred over a directory of files.

    Args:
        db_path: Path to the SQLite database file. Use ``":memory:"``
                 for an ephemeral in-process store.
    """

    def __init__(self, db_path: str | Path = ":memory:") -> None:
        self.db_path = str(db_path)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute(_DDL)
        self._conn.commit()

    def write(self, key: str, value: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        meta_json = json.dumps(metadata) if metadata is not None else None
        self._conn.execute(
            "INSERT OR REPLACE INTO results (key, value, metadata) VALUES (?, ?, ?)",
            (key, value, meta_json),
        )
        self._conn.commit()
        return key

    def read(self, key: str) -> Optional[str]:
        row = self._conn.execute(
            "SELECT value FROM results WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def list(self, prefix: str = "") -> list[str]:
        if prefix:
            rows = self._conn.execute(
                "SELECT key FROM results WHERE key LIKE ? ORDER BY key",
                (f"{prefix}%",),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT key FROM results ORDER BY key"
            ).fetchall()
        return [r[0] for r in rows]

    def delete(self, key: str) -> bool:
        cursor = self._conn.execute("DELETE FROM results WHERE key = ?", (key,))
        self._conn.commit()
        return cursor.rowcount > 0

    def clear(self) -> None:
        self._conn.execute("DELETE FROM results")
        self._conn.commit()

    def close(self) -> None:
        """Close the underlying database connection."""
        self._conn.close()

    def __del__(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass
