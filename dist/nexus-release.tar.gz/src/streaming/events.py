from enum import Enum
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Set, Optional
from datetime import datetime
import json
from asyncio import Lock


class EventType(str, Enum):
    PLAN_CREATED = "plan_created"
    THOUGHT = "thought"
    ACTION = "action"
    OBSERVATION = "observation"
    CHECKPOINT_SAVED = "checkpoint_saved"
    METRICS_UPDATE = "metrics_update"
    TODO_STATUS_CHANGE = "todo_status_change"
    DONE = "done"
    ERROR = "error"


@dataclass
class StreamEvent:
    type: EventType
    data: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_json(self) -> str:
        return json.dumps({
            'type': self.type.value,
            'data': self.data,
            'timestamp': self.timestamp.isoformat()
        })

    @classmethod
    def from_json(cls, json_str: str) -> 'StreamEvent':
        obj = json.loads(json_str)
        return cls(
            type=EventType(obj['type']),
            data=obj['data'],
            timestamp=datetime.fromisoformat(obj['timestamp'])
        )


class WebSocketBroadcaster:
    def __init__(self):
        self.clients: Set[Any] = set()
        self._lock = Lock()

    async def connect(self, websocket) -> None:
        """Register a WebSocket client."""
        async with self._lock:
            self.clients.add(websocket)

    async def disconnect(self, websocket) -> None:
        """Unregister a WebSocket client."""
        async with self._lock:
            self.clients.discard(websocket)

    async def broadcast(self, event: StreamEvent) -> None:
        """Broadcast an event to all connected clients."""
        json_data = event.to_json()
        disconnected = set()

        for client in self.clients:
            try:
                await client.send_text(json_data)
            except Exception:
                disconnected.add(client)

        # Clean up failed connections
        if disconnected:
            async with self._lock:
                self.clients -= disconnected
