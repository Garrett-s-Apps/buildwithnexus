"""Context boundary management for subagents."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from langchain_core.messages import BaseMessage


class ContextBoundary:
    """Defines what context a subagent receives.

    A boundary filters the full workflow state down to only the information
    relevant to a single subagent's goal, preventing context overflow.

    Fields:
        allowed_todo_ids: Only include intermediate results for these todos.
        max_messages: Maximum number of messages to pass from parent context.
        include_plan: Whether to include the full plan or just the current todo.
        extra_context: Arbitrary additional context key-value pairs.
    """

    def __init__(
        self,
        allowed_todo_ids: Optional[List[str]] = None,
        max_messages: int = 10,
        include_plan: bool = False,
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.allowed_todo_ids = allowed_todo_ids or []
        self.max_messages = max_messages
        self.include_plan = include_plan
        self.extra_context = extra_context or {}


class ContextIsolator:
    """Applies a ContextBoundary to a full workflow state, producing a
    minimal context dict safe to pass to a subagent.

    Usage::

        isolator = ContextIsolator()
        boundary = ContextBoundary(allowed_todo_ids=["abc-123"], max_messages=5)
        subagent_ctx = isolator.extract(full_state, boundary)
    """

    def extract(
        self,
        full_state: Dict[str, Any],
        boundary: ContextBoundary,
    ) -> Dict[str, Any]:
        """Extract a minimal context slice from full_state.

        Args:
            full_state: The complete AgentExecutionState dict.
            boundary: Rules defining what to include.

        Returns:
            A filtered dict suitable for subagent initialisation.
        """
        ctx: Dict[str, Any] = {}

        # Messages: take the N most recent
        messages: List[BaseMessage] = full_state.get("messages", [])
        ctx["messages"] = messages[-boundary.max_messages:] if messages else []

        # Intermediate results: filter by allowed todo ids
        all_results: Dict[str, Any] = full_state.get("intermediate_results", {})
        if boundary.allowed_todo_ids:
            ctx["intermediate_results"] = {
                k: v for k, v in all_results.items()
                if k in boundary.allowed_todo_ids
            }
        else:
            ctx["intermediate_results"] = {}

        # Plan: optionally include
        if boundary.include_plan:
            ctx["plan"] = full_state.get("plan", {})

        # Current task context
        ctx["current_task"] = full_state.get("current_task")
        ctx["agent_role"] = full_state.get("agent_role")
        ctx["agent_goal"] = full_state.get("agent_goal")

        # Extra context passthrough
        ctx.update(boundary.extra_context)

        return ctx
