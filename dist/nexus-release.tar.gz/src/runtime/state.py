from typing import TypedDict, Annotated, Optional, List
from langchain_core.messages import BaseMessage
import operator


class Todo(TypedDict):
    id: str
    title: str
    description: str
    status: str  # pending | in_progress | done
    created_at: str
    completed_at: Optional[str]


class PlanState(TypedDict):
    todos: Annotated[List[Todo], operator.add]  # append-only list
    current_todo_id: Optional[str]
    completed_count: int


class AgentExecutionState(TypedDict):
    """Main execution state for Deep Agents workflow"""
    # Planning
    plan: PlanState

    # Current context
    current_task: Optional[str]
    agent_role: Optional[str]
    agent_goal: Optional[str]

    # Execution
    messages: Annotated[List[BaseMessage], operator.add]  # ReAct transcript
    current_tool_calls: dict

    # Results
    intermediate_results: dict  # {todo_id: result}
    final_result: Optional[str]

    # API key (passed from CLI, falls back to env var in nodes)
    api_key: Optional[str]

    # Metadata
    tokens_used: int
    cost_usd: float
    wall_clock_seconds: int
    checkpoint_count: int
