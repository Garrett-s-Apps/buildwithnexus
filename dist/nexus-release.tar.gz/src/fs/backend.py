from abc import ABC, abstractmethod
from typing import Optional, Dict, Any


class FilesystemBackend(ABC):
    """Abstract interface for persistent storage of intermediate results."""

    @abstractmethod
    def write(self, key: str, value: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Write intermediate result. Returns file path/handle."""
        pass

    @abstractmethod
    def read(self, key: str) -> Optional[str]:
        """Read intermediate result. Returns None if key not found."""
        pass

    @abstractmethod
    def list(self, prefix: str = "") -> list[str]:
        """List keys with optional prefix filter."""
        pass

    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete intermediate result. Returns True if key existed."""
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all intermediate results."""
        pass
