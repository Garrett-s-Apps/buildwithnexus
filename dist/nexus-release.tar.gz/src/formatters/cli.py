"""CLI/terminal-optimized response formatter."""

import sys


class CLIFormatter:
    """Formats responses for terminal output."""

    def format_response(self, text: str, agent_id: str = "", metadata: dict | None = None) -> str:
        return text  # CLI gets plain text

    def format_error(self, error: str, code: str = "") -> str:
        prefix = f"[{code}] " if code else ""
        return f"ERROR: {prefix}{error}"

    def format_status(self, directive_id: str, tasks: list[dict], cost: float = 0.0) -> str:
        lines = [f"Directive {directive_id[:8]}:"]
        for task in tasks:
            symbol = {"completed": "+", "running": "~", "failed": "!", "pending": "-"}.get(
                task.get("status", ""), "?"
            )
            lines.append(f"  [{symbol}] {task.get('description', 'Task')}")
        if cost > 0:
            lines.append(f"  Cost: ${cost:.4f}")
        return "\n".join(lines)

    def format_thinking(self, reasoning: str, agent_id: str = "") -> str:
        """Stream agent thinking to stderr for real-time visibility in TUI."""
        prefix = f"[{agent_id}]" if agent_id else "[Agent]"
        msg = f"{prefix} {reasoning[:100]}"
        # Stream to stderr so it appears in-terminal without buffering
        sys.stderr.write(f"{msg}\n")
        sys.stderr.flush()
        return msg

    def stream_agent_invoke(self, agent_name: str, action: str) -> None:
        """Stream agent invocation to show orchestration in real-time."""
        msg = f"→ {agent_name} ({action})"
        sys.stderr.write(f"{msg}\n")
        sys.stderr.flush()
