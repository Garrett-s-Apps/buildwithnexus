"""
Knowledge retrieval tools for Deep Agents.

Wraps the existing RAG pipeline so agents can query institutional knowledge
during execution and save new findings back for future runs.
"""

import asyncio
import concurrent.futures
import hashlib
import logging
import time

from langchain_core.tools import tool

from src.ml import rag
from src.ml.knowledge_store import KnowledgeStore

logger = logging.getLogger(__name__)


def _run_async(coro):
    """Run an async coroutine from a sync context.

    Uses a thread-pool when a running event loop is detected to avoid
    calling asyncio.run() inside an existing loop, otherwise starts a
    fresh loop directly.
    """
    try:
        asyncio.get_running_loop()
        # Already inside an event loop — run in a worker thread.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()
    except RuntimeError:
        return asyncio.run(coro)


class KnowledgeRetrievalTool:
    """LangChain tools that expose the RAG knowledge base to Deep Agents.

    Provides two tools:
    - query_knowledge: semantic search over accumulated knowledge chunks
    - save_to_knowledge: persist a new finding for future agent runs

    Both tools are bound to the shared KnowledgeStore so agents can read
    and write institutional memory within a single workflow execution.
    """

    def __init__(self, knowledge_store: KnowledgeStore) -> None:
        self.knowledge_store = knowledge_store
        # Bind tool methods so `self` is captured in their closures.
        self.query_knowledge = self._make_query_tool()
        self.save_to_knowledge = self._make_save_tool()

    def _make_query_tool(self):
        """Return a LangChain tool that performs semantic retrieval."""

        @tool
        def query_knowledge(query: str, top_k: int = 5) -> str:
            """Query the knowledge base using semantic search.

            Use this when you need to:
            - Look up previous solutions to similar problems
            - Retrieve organizational knowledge
            - Find relevant context for decision-making

            Args:
                query: Natural language query (e.g. "How do we handle authentication?")
                top_k: Number of results to return (default 5)

            Returns:
                Formatted results with relevance scores
            """
            try:
                results = _run_async(rag.retrieve_async(query, top_k=top_k))
            except Exception as exc:
                logger.warning("query_knowledge failed: %s", exc)
                return "## Knowledge Base Results\n\nNo results found (retrieval error)."

            if not results:
                return "## Knowledge Base Results\n\nNo relevant knowledge found for this query."

            lines = ["## Knowledge Base Results"]
            for i, chunk in enumerate(results, 1):
                score_pct = f"{chunk['score']:.2%}"
                lines.append(f"\n**Result {i}** (relevance: {score_pct})")
                lines.append(chunk["content"])
                source = chunk.get("source_id") or (chunk.get("metadata") or {}).get("source")
                if source:
                    lines.append(f"*Source: {source}*")
            return "\n".join(lines)

        return query_knowledge

    def _make_save_tool(self):
        """Return a LangChain tool that ingests a new knowledge chunk."""

        @tool
        def save_to_knowledge(
            content: str,
            tags: list[str],
            source: str | None = None,
        ) -> str:
            """Save an important finding to the knowledge base for future reference.

            Use this after solving a problem, making a key decision, or discovering
            important information that should be retained for future agent runs.

            Args:
                content: The knowledge to save
                tags: List of tags for categorization (e.g. ["auth", "security"])
                source: Optional source/citation

            Returns:
                Confirmation with knowledge ID
            """
            tag_str = ",".join(tags)
            # Build a stable source_id from content hash + tags so repeated
            # saves with identical content are deduplicated automatically.
            content_hash = hashlib.md5(
                content[:500].encode(), usedforsecurity=False
            ).hexdigest()[:12]
            source_id = f"agent:{content_hash}:{tag_str[:40]}"

            metadata: dict = {
                "tags": tags,
                "created_by": "agent",
                "timestamp": time.time(),
            }
            if source:
                metadata["source"] = source

            try:
                success = _run_async(
                    rag.ingest_async(
                        chunk_type="task_outcome",
                        content=content,
                        source_id=source_id,
                        metadata=metadata,
                    )
                )
            except Exception as exc:
                logger.warning("save_to_knowledge failed: %s", exc)
                return f"Failed to save to knowledge base: {exc}"

            if success:
                return f"Saved to knowledge base (ID: {source_id})"
            return "Failed to save to knowledge base (ingest returned False)."

        return save_to_knowledge
