"""FastAPI server for Deep Agents workflows."""
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
import asyncio
import json

import uvicorn
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .runtime.executor import DeepAgentExecutor
from .interrupts.handlers import InterruptHandler


# Models
class RunRequest(BaseModel):
    task: str
    agent_role: str = "engineer"
    agent_goal: str = ""
    api_key: str = ""


class InterruptRequest(BaseModel):
    run_id: str
    interrupt_type: str
    payload: dict = {}


# Global state
interrupt_handler = InterruptHandler()
active_runs: dict = {}


# Simple event queue for streaming
class EventQueue:
    def __init__(self):
        self.queues: dict[str, asyncio.Queue] = {}

    def create(self, run_id: str):
        self.queues[run_id] = asyncio.Queue()

    async def emit(self, run_id: str, event_type: str, data: dict):
        """Emit an event to all listeners."""
        if run_id in self.queues:
            await self.queues[run_id].put({"type": event_type, "data": data})

    async def get(self, run_id: str):
        """Get next event."""
        if run_id in self.queues:
            return await self.queues[run_id].get()
        return None

    def cleanup(self, run_id: str):
        if run_id in self.queues:
            del self.queues[run_id]


event_queue = EventQueue()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Deep Agents server starting on http://127.0.0.1:4200")
    yield
    print("Deep Agents server shutting down")


app = FastAPI(
    title="Deep Agents API",
    version="0.5.17",
    lifespan=lifespan,
)

# CORS for dashboard on 4201
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4201", "http://localhost:4202"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok", "version": "0.5.17"}


async def _execute_task(run_id: str, request: RunRequest):
    """Background executor task."""
    try:
        await event_queue.emit(run_id, "started", {"task": request.task})

        executor = DeepAgentExecutor(event_queue=event_queue, run_id=run_id)

        result = await executor.async_run(
            task=request.task,
            agent_role=request.agent_role,
            agent_goal=request.agent_goal,
            thread_id=run_id,
            api_key=request.api_key or None,
        )

        active_runs[run_id]["status"] = "done"
        active_runs[run_id]["result"] = result

        await event_queue.emit(run_id, "done", {"result": str(result)})

    except Exception as e:
        active_runs[run_id]["status"] = "error"
        active_runs[run_id]["error"] = str(e)
        await event_queue.emit(run_id, "error", {"error": str(e)})


@app.post("/api/run")
async def run_task(request: RunRequest):
    """Start a task and return SSE stream endpoint."""
    run_id = str(uuid.uuid4())[:8]

    active_runs[run_id] = {
        "status": "running",
        "task": request.task,
        "agent_role": request.agent_role,
        "started_at": datetime.utcnow().isoformat(),
    }

    event_queue.create(run_id)

    # Start execution in background
    asyncio.create_task(_execute_task(run_id, request))

    return {"run_id": run_id}


@app.get("/api/stream/{run_id}")
async def stream_events(run_id: str):
    """Server-Sent Events endpoint for streaming task output."""

    async def event_generator():
        timeout = 0
        while timeout < 300:  # 5 minute timeout
            if run_id not in event_queue.queues:
                break
            try:
                event = await asyncio.wait_for(event_queue.get(run_id), timeout=1.0)
                if event:
                    yield f"data: {json.dumps(event)}\n\n"
                    if event["type"] == "done" or event["type"] == "error":
                        event_queue.cleanup(run_id)
                        break
            except asyncio.TimeoutError:
                timeout += 1
                continue

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/api/agents")
async def list_agents():
    return {
        "agents": [
            {"name": "ceo", "role": "executive"},
            {"name": "engineer", "role": "developer"},
            {"name": "researcher", "role": "investigator"},
            {"name": "reviewer", "role": "validator"},
            {"name": "planner", "role": "organizer"},
            {"name": "qa_engineer", "role": "tester"},
            {"name": "devops", "role": "infrastructure"},
            {"name": "designer", "role": "architect"},
        ]
    }


@app.get("/api/checkpoint/{run_id}")
async def get_checkpoint(run_id: str):
    run = active_runs.get(run_id)
    if not run:
        return {"error": f"Run {run_id} not found"}
    return run


@app.post("/api/interrupt")
async def send_interrupt(request: InterruptRequest):
    if request.interrupt_type not in ["pause", "resume", "modify", "abort"]:
        return {"error": "Invalid interrupt type"}

    run = active_runs.get(request.run_id)
    if not run:
        return {"error": f"Run {request.run_id} not found"}

    return {"handled": True, "message": f"Interrupt {request.interrupt_type} sent"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 4200))
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=port,
        log_level="info",
    )
