"""Main LangGraph graph builder for Deep Agents workflow."""
from typing import Any

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph

from .nodes import execution_node, planning_node, brainstorm_node
from .state import AgentExecutionState


def _checkpoint_node(state: AgentExecutionState) -> dict:
    """Node: persist intermediate results and increment checkpoint counter."""
    return {"checkpoint_count": state.get("checkpoint_count", 0) + 1}


def _routing_node(state: AgentExecutionState) -> dict:
    """Entry point router: dispatch to brainstorm or plan based on agent_role."""
    # This is a no-op node that just passes through
    # The actual routing happens via conditional edges
    return {}


def _route_entry(state: AgentExecutionState) -> str:
    """Route to entry point based on agent_role."""
    agent_role = state.get("agent_role", "assistant")
    if agent_role == "brainstorm":
        return "brainstorm"
    return "plan"


def _should_continue(state: AgentExecutionState) -> str:
    """Routing function: continue execution or finish."""
    plan = state.get("plan", {})
    todos = plan.get("todos", [])
    pending = [t for t in todos if t["status"] != "done"]
    if pending:
        return "execute"
    return END


def _make_memory_checkpointer() -> MemorySaver:
    """Create a MemorySaver for in-memory checkpoint persistence."""
    return MemorySaver()


def build_graph(
    checkpointer: Any = None,
    knowledge_store: Any | None = None,
) -> StateGraph:
    """Build and compile the Deep Agents LangGraph graph.

    Args:
        checkpointer: Optional LangGraph checkpointer for persistence.
                      Defaults to MemorySaver for in-memory persistence.
        knowledge_store: Optional KnowledgeStore instance. When provided,
                         query_knowledge and save_to_knowledge tools are
                         added to the agent toolset so it can read and write
                         institutional memory during execution.

    Returns:
        Compiled StateGraph ready for invocation.
    """
    if checkpointer is None:
        checkpointer = _make_memory_checkpointer()

    # Build the tool list, injecting knowledge tools when a store is provided.
    from src.planning.planning_tool import WriteTodosTool

    planning_tool = WriteTodosTool()
    tools: list[Any] = [
        planning_tool.write_todos,
    ]

    if knowledge_store is not None:
        from src.knowledge.retrieval_tool import KnowledgeRetrievalTool

        knowledge_tool = KnowledgeRetrievalTool(knowledge_store)
        tools.append(knowledge_tool.query_knowledge)
        tools.append(knowledge_tool.save_to_knowledge)

    builder = StateGraph(AgentExecutionState)

    # Add routing node as entry point
    builder.add_node("start", _routing_node)
    builder.add_node("plan", planning_node)
    builder.add_node("brainstorm", brainstorm_node)
    builder.add_node("execute", execution_node)
    builder.add_node("checkpoint", _checkpoint_node)

    # Set entry point and routing
    builder.set_entry_point("start")
    builder.add_conditional_edges(
        "start",
        _route_entry,
        {"plan": "plan", "brainstorm": "brainstorm"},
    )

    builder.add_edge("plan", "checkpoint")
    builder.add_edge("brainstorm", END)
    builder.add_conditional_edges(
        "checkpoint",
        _should_continue,
        {"execute": "execute", END: END},
    )
    builder.add_edge("execute", "checkpoint")

    return builder.compile(checkpointer=checkpointer)
