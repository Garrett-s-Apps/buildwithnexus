"""Pause, resume, and modify interrupt handlers for Deep Agents."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class InterruptType(str, Enum):
    PAUSE = "pause"
    RESUME = "resume"
    MODIFY = "modify"
    ABORT = "abort"


@dataclass
class Interrupt:
    """Represents an interrupt signal sent to a running agent."""
    type: InterruptType
    payload: Dict[str, Any] = field(default_factory=dict)
    reason: str = ""


@dataclass
class InterruptResult:
    handled: bool
    interrupt: Interrupt
    state_patch: Dict[str, Any] = field(default_factory=dict)
    message: str = ""


HandlerFn = Callable[[Interrupt, Dict[str, Any]], InterruptResult]


class InterruptHandler:
    """Registry of interrupt handlers.

    Handlers are registered per InterruptType and invoked when the
    corresponding interrupt is dispatched to a running workflow.

    Usage::

        handler = InterruptHandler()

        @handler.register(InterruptType.PAUSE)
        def on_pause(interrupt, state):
            return InterruptResult(handled=True, interrupt=interrupt,
                                   message="Workflow paused")

        result = handler.dispatch(Interrupt(type=InterruptType.PAUSE), current_state)
    """

    def __init__(self) -> None:
        self._handlers: Dict[InterruptType, List[HandlerFn]] = {
            t: [] for t in InterruptType
        }
        self._register_defaults()

    def _register_defaults(self) -> None:
        """Register built-in no-op handlers for all interrupt types."""

        def _default_pause(interrupt: Interrupt, state: Dict[str, Any]) -> InterruptResult:
            return InterruptResult(
                handled=True,
                interrupt=interrupt,
                state_patch={"_paused": True},
                message=f"Workflow paused: {interrupt.reason}",
            )

        def _default_resume(interrupt: Interrupt, state: Dict[str, Any]) -> InterruptResult:
            return InterruptResult(
                handled=True,
                interrupt=interrupt,
                state_patch={"_paused": False},
                message="Workflow resumed",
            )

        def _default_modify(interrupt: Interrupt, state: Dict[str, Any]) -> InterruptResult:
            patch = interrupt.payload.get("state_patch", {})
            return InterruptResult(
                handled=True,
                interrupt=interrupt,
                state_patch=patch,
                message=f"State modified: {list(patch.keys())}",
            )

        def _default_abort(interrupt: Interrupt, state: Dict[str, Any]) -> InterruptResult:
            return InterruptResult(
                handled=True,
                interrupt=interrupt,
                state_patch={"_aborted": True, "final_result": "Workflow aborted"},
                message=f"Workflow aborted: {interrupt.reason}",
            )

        self._handlers[InterruptType.PAUSE].append(_default_pause)
        self._handlers[InterruptType.RESUME].append(_default_resume)
        self._handlers[InterruptType.MODIFY].append(_default_modify)
        self._handlers[InterruptType.ABORT].append(_default_abort)

    def register(self, interrupt_type: InterruptType) -> Callable[[HandlerFn], HandlerFn]:
        """Decorator to register a custom handler for an interrupt type."""
        def decorator(fn: HandlerFn) -> HandlerFn:
            self._handlers[interrupt_type].append(fn)
            return fn
        return decorator

    def dispatch(
        self,
        interrupt: Interrupt,
        state: Dict[str, Any],
    ) -> InterruptResult:
        """Dispatch an interrupt to all registered handlers.

        Handlers are called in registration order. The state_patch from
        each handler is merged into the cumulative result.

        Args:
            interrupt: The interrupt to handle.
            state: Current workflow state dict.

        Returns:
            InterruptResult with merged state_patch from all handlers.
        """
        handlers = self._handlers.get(interrupt.type, [])
        if not handlers:
            return InterruptResult(
                handled=False,
                interrupt=interrupt,
                message=f"No handlers registered for {interrupt.type}",
            )

        merged_patch: Dict[str, Any] = {}
        last_result: Optional[InterruptResult] = None

        for handler in handlers:
            result = handler(interrupt, state)
            merged_patch.update(result.state_patch)
            last_result = result

        assert last_result is not None
        return InterruptResult(
            handled=True,
            interrupt=interrupt,
            state_patch=merged_patch,
            message=last_result.message,
        )
