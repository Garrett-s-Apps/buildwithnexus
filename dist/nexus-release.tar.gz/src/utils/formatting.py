"""Shared response formatting utilities.

Consolidates duplicate format_response logic across 5 formatter classes
(cli.py, slack.py, neovim.py, api.py, base.py).
"""

import logging

logger = logging.getLogger("nexus.utils.formatting")


def format_response_shared(
    text: str,
    agent_id: str = "",
    metadata: dict | None = None,
    format_type: str = "plain",
) -> str:
    """Format agent response with common boilerplate.

    Replaces duplicate format_response() implementations across formatter classes.
    Handles agent attribution, metadata, and format-specific wrapping.

    Args:
        text: The response text
        agent_id: Agent name/ID for attribution
        metadata: Additional metadata (cost, tokens, etc.)
        format_type: Output format ("plain", "mrkdwn", "html")

    Returns:
        Formatted response string
    """
    if not text:
        return ""

    # Start with agent attribution if provided
    lines = []
    if agent_id:
        lines.append(f"**{agent_id}** responded:")

    # Add main text
    lines.append(text)

    # Add metadata footer if provided
    if metadata:
        footer_parts = []
        if cost := metadata.get("cost"):
            footer_parts.append(f"Cost: {cost}")
        if tokens := metadata.get("tokens"):
            footer_parts.append(f"Tokens: {tokens}")

        if footer_parts:
            lines.append("\n---")
            lines.append(" | ".join(footer_parts))

    response = "\n".join(lines)

    # Format-specific wrapping
    if format_type == "mrkdwn":
        return response  # Slack already expects mrkdwn
    elif format_type == "html":
        response = response.replace("\n", "<br>")
        response = response.replace("**", "<strong>")
        response = response.replace("---", "<hr>")
        return response
    else:  # plain
        return response


def format_error(error: str, code: str = "", format_type: str = "plain") -> str:
    """Format error message with code and styling.

    Args:
        error: Error message text
        code: Optional error code
        format_type: Output format ("plain", "mrkdwn", "html")

    Returns:
        Formatted error string
    """
    if format_type == "mrkdwn":
        parts = [":warning: Error"]
        if code:
            parts.append(f"({code})")
        parts.append(f":\n`{error}`")
        return " ".join(parts)
    elif format_type == "html":
        code_tag = f"({code})" if code else ""
        return f"<strong>⚠️ Error {code_tag}:</strong><br><code>{error}</code>"
    else:  # plain
        code_tag = f"({code})" if code else ""
        return f"Error {code_tag}: {error}"


def format_thinking(reasoning: str, agent_id: str = "") -> str:
    """Format orchestrator thinking/reasoning message.

    Args:
        reasoning: The reasoning text
        agent_id: Agent providing the reasoning

    Returns:
        Formatted thinking message
    """
    if not reasoning:
        return ""

    lines = []
    if agent_id:
        lines.append(f"__{agent_id} thinking__")
    lines.append(reasoning)

    return "\n".join(lines)


def format_status(directive_id: str, tasks: list[dict], cost: float = 0.0) -> str:
    """Format directive status update.

    Args:
        directive_id: Directive identifier
        tasks: List of task dicts with name and status
        cost: Total cost incurred

    Returns:
        Formatted status message
    """
    lines = [f"**Directive:** {directive_id}"]

    if tasks:
        lines.append("**Tasks:**")
        for task in tasks:
            name = task.get("name", "Unknown")
            status = task.get("status", "pending")
            lines.append(f"  • {name}: {status}")

    if cost > 0:
        lines.append(f"\n**Cost:** ${cost:.4f}")

    return "\n".join(lines)
