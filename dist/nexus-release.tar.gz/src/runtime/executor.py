"""Execution engine for Deep Agents."""
from __future__ import annotations

import time
from typing import Any

from .graph import build_graph
from .state import AgentExecutionState


class DeepAgentExecutor:
    """High-level interface for running a Deep Agent workflow.

    Example::

        executor = DeepAgentExecutor()
        result = executor.run(
            task="Refactor the auth module",
            agent_role="software-engineer",
            agent_goal="Improve maintainability and test coverage",
        )
        print(result["final_result"])
    """

    def __init__(
        self,
        checkpointer: Any | None = None,
        knowledge_store: Any | None = None,
        event_queue: Any | None = None,
        run_id: str = "default",
    ) -> None:
        self.graph = build_graph(
            checkpointer=checkpointer,
            knowledge_store=knowledge_store,
        )
        self.event_queue = event_queue
        self.run_id = run_id

        # Register event queue with nodes module
        if event_queue:
            from .nodes import set_event_queue
            set_event_queue(event_queue, run_id)

    @staticmethod
    def _make_initial_state(
        task: str,
        agent_role: str,
        agent_goal: str,
        thread_id: str,
        api_key: str | None = None,
    ) -> AgentExecutionState:
        """Build the initial state dict for a workflow run."""
        return {
            "plan": {"todos": [], "current_todo_id": None, "completed_count": 0},
            "current_task": task,
            "agent_role": agent_role,
            "agent_goal": agent_goal,
            "api_key": api_key,
            "messages": [],
            "current_tool_calls": {},
            "intermediate_results": {},
            "final_result": None,
            "tokens_used": 0,
            "cost_usd": 0.0,
            "wall_clock_seconds": 0,
            "checkpoint_count": 0,
        }

    def run(
        self,
        task: str,
        agent_role: str = "assistant",
        agent_goal: str = "",
        thread_id: str = "default",
        api_key: str | None = None,
    ) -> AgentExecutionState:
        """Execute the Deep Agent workflow for a given task.

        Args:
            task: High-level task description.
            agent_role: Role persona for the agent (e.g. "software-engineer").
            agent_goal: Optional goal/objective statement.
            thread_id: LangGraph thread identifier for checkpointing.
            api_key: Optional Anthropic API key (falls back to env var).

        Returns:
            Final AgentExecutionState after workflow completion.
        """
        initial_state = self._make_initial_state(task, agent_role, agent_goal, thread_id, api_key)
        config = {"configurable": {"thread_id": thread_id}}

        start = time.monotonic()
        final_state = self.graph.invoke(initial_state, config=config)
        elapsed = int(time.monotonic() - start)

        final_state["wall_clock_seconds"] = elapsed
        return final_state

    async def async_run(
        self,
        task: str,
        agent_role: str = "assistant",
        agent_goal: str = "",
        thread_id: str = "default",
        api_key: str | None = None,
    ) -> AgentExecutionState:
        """Async execution with checkpoint persistence.

        Identical to ``run()`` but uses ``graph.ainvoke`` so it can be
        awaited inside an async event loop.

        Args:
            task: High-level task description.
            agent_role: Role persona for the agent (e.g. "software-engineer").
            agent_goal: Optional goal/objective statement.
            thread_id: LangGraph thread identifier for checkpointing.
            api_key: Optional Anthropic API key (falls back to env var).

        Returns:
            Final AgentExecutionState after workflow completion.
        """
        initial_state = self._make_initial_state(task, agent_role, agent_goal, thread_id, api_key)
        config = {"configurable": {"thread_id": thread_id}}

        start = time.monotonic()
        final_state = await self.graph.ainvoke(initial_state, config=config)
        elapsed = int(time.monotonic() - start)

        final_state["wall_clock_seconds"] = elapsed
        return final_state
