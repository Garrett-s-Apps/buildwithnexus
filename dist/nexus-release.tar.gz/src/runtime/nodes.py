"""Real node implementations for Deep Agents LangGraph graph."""
from __future__ import annotations

import asyncio
import os
from typing import TYPE_CHECKING, Any

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

from ..planning.planning_tool import WriteTodosTool

if TYPE_CHECKING:
    from .state import AgentExecutionState

# Global event queue reference - set by executor
_event_queue = None
_run_id = "default"

def set_event_queue(event_queue: Any, run_id: str) -> None:
    """Set the global event queue for streaming."""
    global _event_queue, _run_id
    _event_queue = event_queue
    _run_id = run_id

async def _emit_event(event_type: str, data: dict) -> None:
    """Emit an event to the event queue."""
    if _event_queue is None:
        return
    try:
        await _event_queue.emit(_run_id, event_type, data)
    except Exception:
        pass


async def planning_node(state: AgentExecutionState) -> dict:
    """Planning node: decompose task into todos using LLM + write_todos tool.

    Creates a ChatAnthropic instance with write_todos bound, sends the user
    task for decomposition into 2-5 subtasks, then processes the tool call
    response to populate the plan.

    Args:
        state: Current AgentExecutionState

    Returns:
        State update with populated plan.todos

    Raises:
        ValueError: If ANTHROPIC_API_KEY is not set or authentication fails.
        RuntimeError: If the planning LLM call fails unexpectedly.
    """
    api_key = state.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError(
            "ANTHROPIC_API_KEY environment variable is not set. "
            "Please set it to use Claude for planning: "
            "export ANTHROPIC_API_KEY=sk-..."
        )

    task = state.get("current_task", "")
    role = state.get("agent_role", "assistant")
    goal = state.get("agent_goal", "")

    if not task:
        return {
            "plan": {
                "todos": [],
                "current_todo_id": None,
                "completed_count": 0,
            }
        }

    try:
        # Create LLM with write_todos tool bound
        planning_tool = WriteTodosTool()
        llm = ChatAnthropic(model="claude-sonnet-4-20250514", temperature=0.3, api_key=api_key)
        llm_with_tools = llm.bind_tools([planning_tool.write_todos])

        system_prompt = (
            f"You are a {role} assistant helping to break down a task.\n"
            f"Goal: {goal if goal else 'Complete the task'}\n"
            "\n"
            "Your job is to decompose the user's task into 2-5 concrete, "
            "independent subtasks. Each subtask should be something that "
            "can be executed and validated independently.\n"
            "\n"
            "Use the write_todos tool to create the task breakdown. "
            "Be specific and actionable with each step."
        )

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Task: {task}"),
        ]

        await _emit_event("thought", {"content": f"Planning: Breaking down '{task}' into subtasks"})

        response = llm_with_tools.invoke(messages)

        await _emit_event("observation", {"content": f"Generated plan with {len(response.tool_calls) if response.tool_calls else 0} subtasks"})

        # Process tool calls from the LLM response
        if response.tool_calls:
            for tool_call in response.tool_calls:
                if tool_call["name"] == "write_todos":
                    planning_tool.write_todos.invoke(tool_call["args"])

        todos = planning_tool.get_plan()

        # Emit structured plan event for CLI to display and prompt user
        steps = [t.get("title", t.get("id", "")) for t in todos]
        await _emit_event("plan", {
            "task": task,
            "steps": steps,
            "todos": todos,
        })

        return {
            "plan": {
                "todos": todos,
                "current_todo_id": todos[0]["id"] if todos else None,
                "completed_count": 0,
            },
            "messages": [response],
        }

    except Exception as e:
        # Surface auth errors clearly
        err_str = str(e).lower()
        if "auth" in err_str or "api key" in err_str or "401" in err_str:
            raise ValueError(
                "Authentication failed with ANTHROPIC_API_KEY. "
                f"Error: {e}. "
                "Please verify your API key is correct."
            ) from e
        raise RuntimeError(f"Planning node failed: {e}") from e


async def execution_node(state: AgentExecutionState) -> dict[str, Any]:
    """Process the current todo via a ReAct loop with role-appropriate tools.

    Finds the first pending/in_progress todo, binds tools for the agent role,
    and runs a ReAct (Reason+Act) loop capped at 10 iterations.  Marks the
    todo as done and stores the result in intermediate_results.

    Args:
        state: Current AgentExecutionState.

    Returns:
        State update dict with messages, plan, intermediate_results,
        tokens_used, and cost_usd.
    """
    from src.tools import get_tools_for_role

    # --- Validate API key ---------------------------------------------------
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {
            "final_result": "ERROR: ANTHROPIC_API_KEY not set",
            "plan": state.get("plan", {}),
        }

    # --- Locate current todo -------------------------------------------------
    plan: dict[str, Any] = dict(state.get("plan", {}))
    todos: list[dict[str, Any]] = [dict(t) for t in plan.get("todos", [])]

    current_todo: dict[str, Any] | None = None
    for todo in todos:
        if todo["status"] in ("pending", "in_progress"):
            current_todo = todo
            break

    if current_todo is None:
        return {
            "final_result": "All tasks complete",
            "plan": plan,
        }

    # Mark in_progress
    current_todo["status"] = "in_progress"

    # --- Resolve tools for role ----------------------------------------------
    role = state.get("agent_role", "assistant") or "assistant"
    tools = get_tools_for_role(role)

    if not tools:
        # No tools available -- mark done immediately
        current_todo["status"] = "done"
        plan["todos"] = todos
        plan["completed_count"] = sum(1 for t in todos if t["status"] == "done")

        existing_results = dict(state.get("intermediate_results", {}))
        existing_results[current_todo["id"]] = "Completed (no tools available for role)"

        return {
            "intermediate_results": existing_results,
            "plan": plan,
        }

    # --- Build LLM with tools ------------------------------------------------
    try:
        llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            temperature=0.2,
            api_key=api_key,
        )
        llm_with_tools = llm.bind_tools(tools)
    except Exception as e:
        current_todo["status"] = "done"
        plan["todos"] = todos
        plan["completed_count"] = sum(1 for t in todos if t["status"] == "done")

        existing_results = dict(state.get("intermediate_results", {}))
        existing_results[current_todo["id"]] = f"Error initialising LLM: {e}"

        return {
            "intermediate_results": existing_results,
            "plan": plan,
        }

    # --- ReAct loop ----------------------------------------------------------
    system_prompt = (
        f"You are a {role} assistant.\n"
        f"Task: {current_todo['title']}\n"
        f"Description: {current_todo.get('description', '')}\n\n"
        "Use the available tools to complete this task. "
        "Be systematic and check your work."
    )

    # Only new messages produced by this node (appended via operator.add)
    new_messages: list[Any] = [
        SystemMessage(content=system_prompt),
        HumanMessage(content="Begin executing this task."),
    ]

    max_iterations = 10
    iterations = 0
    result_text = ""
    total_input_tokens = 0
    total_output_tokens = 0

    try:
        # Seed the conversation for first invoke
        conversation: list[Any] = list(new_messages)

        while iterations < max_iterations:
            iterations += 1

            if iterations == 1:
                await _emit_event("agent_working", {
                    "agent": role,
                    "task": current_todo["title"],
                    "step": current_todo.get("id", ""),
                })

            response = llm_with_tools.invoke(conversation)

            if hasattr(response, 'content'):
                content_preview = str(response.content)[:200]
                await _emit_event("observation", {"content": content_preview})

            new_messages.append(response)
            conversation.append(response)

            # Accumulate token usage from response metadata
            usage = getattr(response, "usage_metadata", None)
            if usage:
                total_input_tokens += usage.get("input_tokens", 0)
                total_output_tokens += usage.get("output_tokens", 0)

            # If no tool calls, the agent is done reasoning
            if not response.tool_calls:
                if hasattr(response, "content"):
                    result_text = (
                        response.content
                        if isinstance(response.content, str)
                        else str(response.content)
                    )
                break

            # Process each tool call
            for tool_call in response.tool_calls:
                tool_name = tool_call.get("name")
                tool_args = tool_call.get("args", {})
                tool_use_id = tool_call.get("id")
                await _emit_event("action", {"content": f"Calling tool: {tool_name}({str(tool_args)[:100]})", "agent": role, "tool": tool_name})

                # Find matching tool and invoke
                tool_output: str | None = None
                for t in tools:
                    if t.name == tool_name:
                        try:
                            tool_output = str(t.invoke(tool_args))
                        except Exception as exc:
                            tool_output = f"Tool error: {exc}"
                        break

                if tool_output is None:
                    tool_output = f"Unknown tool: {tool_name}"

                tool_msg = ToolMessage(
                    content=tool_output,
                    tool_call_id=tool_use_id,
                )
                new_messages.append(tool_msg)
                conversation.append(tool_msg)

    except Exception as e:
        result_text = f"ReAct loop error: {e}"

    # --- Finalise todo -------------------------------------------------------
    current_todo["status"] = "done"
    plan["todos"] = todos
    plan["completed_count"] = sum(1 for t in todos if t["status"] == "done")

    todo_result = result_text or f"Completed in {iterations} iteration(s)"

    existing_results = dict(state.get("intermediate_results", {}))
    existing_results[current_todo["id"]] = todo_result

    # Emit agent_result for this todo
    await _emit_event("agent_result", {
        "agent": role,
        "task": current_todo["title"],
        "result": todo_result,
        "step": current_todo.get("id", ""),
    })

    # If all todos are done, emit execution_complete with full summary
    all_done = all(t["status"] == "done" for t in todos)
    if all_done:
        completed_results = dict(existing_results)
        # Merge any prior results not yet in existing_results
        for k, v in state.get("intermediate_results", {}).items():
            if k not in completed_results:
                completed_results[k] = v
        summary_lines = [
            f"- {t.get('title', t['id'])}: {completed_results.get(t['id'], 'done')}"
            for t in todos
        ]
        await _emit_event("execution_complete", {
            "summary": "\n".join(summary_lines),
            "todos_completed": len(todos),
            "steps": [t.get("title", t["id"]) for t in todos],
        })

    # Approximate cost: input $3/M, output $15/M for Sonnet
    estimated_cost = (
        (total_input_tokens * 3.0 + total_output_tokens * 15.0) / 1_000_000
    )

    return {
        "messages": new_messages,
        "intermediate_results": existing_results,
        "plan": plan,
        "tokens_used": (
            state.get("tokens_used", 0) + total_input_tokens + total_output_tokens
        ),
        "cost_usd": state.get("cost_usd", 0.0) + estimated_cost,
    }


async def brainstorm_node(state: AgentExecutionState) -> dict:
    """Brainstorm node: Direct conversation with Claude, no planning.

    For brainstorm mode, skip planning and execute an immediate response
    to the user's query using Claude Haiku.

    Args:
        state: Current AgentExecutionState

    Returns:
        State update with response and events
    """
    api_key = state.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError(
            "ANTHROPIC_API_KEY environment variable is not set. "
            "Please set it to use Claude for brainstorming."
        )

    task = state.get("current_task", "")
    goal = state.get("agent_goal", "")

    if not task:
        return {
            "final_result": "",
            "messages": [],
            "intermediate_results": {},
            "plan": {"todos": [], "current_todo_id": None, "completed_count": 0},
            "tokens_used": 0,
            "cost_usd": 0.0,
        }

    try:
        # Create LLM for brainstorm (using Haiku for speed/cost)
        llm = ChatAnthropic(model="claude-3-5-haiku-20241022", temperature=0.7, api_key=api_key)

        system_prompt = (
            "You are a helpful brainstorming assistant. Provide creative, "
            "practical ideas and thoughtful responses. Be concise but comprehensive.\n"
        )
        if goal:
            system_prompt += f"Goal: {goal}\n"

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=task),
        ]

        await _emit_event("thought", {"content": f"Brainstorming: {task}"})

        response = llm.invoke(messages)
        response_text = response.content

        await _emit_event("observation", {"content": response_text})
        await _emit_event("execution_complete", {
            "summary": response_text,
            "todos_completed": 1,
        })

        # Track token usage (approximate)
        input_tokens = len(task) // 4 + 50  # rough estimate
        output_tokens = len(response_text) // 4
        estimated_cost = ((input_tokens * 0.8 + output_tokens * 4.0) / 1_000_000)

        return {
            "final_result": response_text,
            "messages": messages + [response],
            "intermediate_results": {"brainstorm": response_text},
            "plan": {"todos": [], "current_todo_id": None, "completed_count": 0},
            "tokens_used": input_tokens + output_tokens,
            "cost_usd": estimated_cost,
        }

    except Exception as e:
        error_msg = f"Brainstorm error: {str(e)}"
        await _emit_event("error", {"error": error_msg})
        return {
            "final_result": "",
            "messages": [],
            "intermediate_results": {},
            "plan": {"todos": [], "current_todo_id": None, "completed_count": 0},
            "tokens_used": 0,
            "cost_usd": 0.0,
        }
