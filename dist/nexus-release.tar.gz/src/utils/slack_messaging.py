"""Unified Slack message sending and thinking indicator management.

Consolidates the 3 triplicate patterns of Slack chat_postMessage calls
and provides a context manager for thinking indicator (spinner) lifecycle.
"""

import logging
from contextlib import asynccontextmanager

from slack_sdk.web.async_client import AsyncWebClient

logger = logging.getLogger("nexus.utils.slack_messaging")


async def send_slack_message(
    web_client: AsyncWebClient,
    channel_id: str,
    text: str,
    thread_ts: str | None = None,
    blocks: list[dict] | None = None,
) -> str | None:
    """Send a Slack message with automatic chunking for large text.

    Handles three message patterns:
    - Normal text messages
    - Block Kit formatted messages (with code)
    - Automatic chunking for messages >3900 chars

    Args:
        web_client: AsyncWebClient instance
        channel_id: Target channel ID
        text: Message text (mrkdwn format)
        thread_ts: Optional thread timestamp for threading
        blocks: Optional Block Kit blocks for rich formatting

    Returns:
        Timestamp of the posted message, or None on error
    """
    if not text and not blocks:
        logger.warning("send_slack_message: empty text and blocks")
        return None

    try:
        kwargs = {
            "channel": channel_id,
            "text": text,
        }
        if thread_ts:
            kwargs["thread_ts"] = thread_ts
        if blocks:
            kwargs["blocks"] = blocks

        # If text is too long and no blocks, chunk it
        if text and len(text) > 3900 and not blocks:
            chunks = [text[i : i + 3900] for i in range(0, len(text), 3900)]
            last_ts = None
            for chunk in chunks:
                result = await web_client.chat_postMessage(
                    channel=channel_id, text=chunk, thread_ts=thread_ts
                )
                last_ts = result.get("ts")
            return last_ts

        # Send single message (either normal or with blocks)
        result = await web_client.chat_postMessage(**kwargs)
        return result.get("ts")

    except Exception as e:
        logger.error(f"Failed to send Slack message: {e}", exc_info=True)
        return None


async def update_slack_message(
    web_client: AsyncWebClient,
    channel_id: str,
    ts: str,
    text: str,
    blocks: list[dict] | None = None,
) -> bool:
    """Update an existing Slack message.

    Args:
        web_client: AsyncWebClient instance
        channel_id: Target channel ID
        ts: Message timestamp to update
        text: New message text
        blocks: Optional Block Kit blocks

    Returns:
        True if update succeeded, False otherwise
    """
    try:
        kwargs = {
            "channel": channel_id,
            "ts": ts,
            "text": text,
        }
        if blocks:
            kwargs["blocks"] = blocks

        await web_client.chat_update(**kwargs)
        return True

    except Exception as e:
        logger.error(f"Failed to update Slack message: {e}", exc_info=True)
        return False


async def delete_slack_message(
    web_client: AsyncWebClient,
    channel_id: str,
    ts: str,
) -> bool:
    """Delete a Slack message.

    Args:
        web_client: AsyncWebClient instance
        channel_id: Target channel ID
        ts: Message timestamp to delete

    Returns:
        True if deletion succeeded, False otherwise
    """
    try:
        await web_client.chat_delete(channel=channel_id, ts=ts)
        return True
    except Exception as e:
        logger.error(f"Failed to delete Slack message: {e}", exc_info=True)
        return False


@asynccontextmanager
async def ThinkingIndicator(
    web_client: AsyncWebClient,
    channel_id: str,
    thread_ts: str,
    initial_text: str = ":hourglass_flowing_sand: Processing...",
):
    """Context manager for Slack thinking indicator (spinner).

    Ensures cleanup on exit (success or error). Replaces the 6 separate
    try/except blocks in listener.py with guaranteed cleanup.

    Usage:
        async with ThinkingIndicator(web_client, channel, thread) as indicator:
            await indicator.update("New status...")
            # do work
            # indicator automatically deleted on exit

    Args:
        web_client: AsyncWebClient instance
        channel_id: Target channel ID
        thread_ts: Thread timestamp
        initial_text: Initial thinking message text

    Yields:
        ThinkingIndicatorHandle for updating the message
    """
    ts = None
    try:
        # Post initial thinking message
        result = await send_slack_message(
            web_client, channel_id, initial_text, thread_ts=thread_ts
        )
        ts = result
        yield ThinkingIndicatorHandle(web_client, channel_id, ts)
    finally:
        # Always clean up on exit (success or exception)
        if ts:
            await delete_slack_message(web_client, channel_id, ts)


class ThinkingIndicatorHandle:
    """Handle for updating thinking indicator during operation."""

    def __init__(
        self, web_client: AsyncWebClient, channel_id: str, ts: str | None
    ):
        self.web_client = web_client
        self.channel_id = channel_id
        self.ts = ts

    async def update(self, text: str) -> bool:
        """Update the thinking indicator text.

        Args:
            text: New status text

        Returns:
            True if update succeeded, False otherwise
        """
        if not self.ts:
            return False
        return await update_slack_message(
            self.web_client, self.channel_id, self.ts, text
        )
