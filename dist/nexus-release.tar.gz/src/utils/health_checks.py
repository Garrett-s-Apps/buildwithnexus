"""Shared database health check logic.

Consolidates duplicate DB connectivity checks from /health and /health/detail
endpoints into a single reusable function.
"""

import logging

logger = logging.getLogger("nexus.utils.health_checks")


async def check_db_connectivity() -> tuple[dict[str, bool], str]:
    """Check database connectivity and return structured results.

    Replaces duplicate logic in src/daemon/server.py /health and /health/detail
    endpoints. Performs 5 key DB checks:
    1. Connection pool availability
    2. Memory store readiness
    3. SQLite store readiness
    4. Encryption layer readiness
    5. Overall connectivity status

    Returns:
        Tuple of:
        - checks_dict: {check_name: bool} for each check
        - overall_status: "healthy" or "degraded"
    """
    checks = {}

    try:
        from src.db.pool import get_pool

        pool = get_pool()
        checks["pool_available"] = pool is not None
    except Exception as e:
        logger.warning(f"Pool check failed: {e}")
        checks["pool_available"] = False

    try:
        from src.memory.store import memory

        checks["memory_store"] = memory is not None
    except Exception as e:
        logger.warning(f"Memory store check failed: {e}")
        checks["memory_store"] = False

    try:
        from src.db.sqlite_store import sqlite_store

        checks["sqlite_store"] = sqlite_store is not None
    except Exception as e:
        logger.warning(f"SQLite store check failed: {e}")
        checks["sqlite_store"] = False

    try:
        from src.db.encryption import encryption_service

        checks["encryption"] = encryption_service is not None
    except Exception as e:
        logger.warning(f"Encryption check failed: {e}")
        checks["encryption"] = False

    # Overall status: healthy if all checks pass
    overall_status = "healthy" if all(checks.values()) else "degraded"

    return checks, overall_status
