"""Subagent spawning logic for Deep Agents."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class SubagentSpec:
    """Specification for a subagent to be spawned."""
    role: str
    goal: str
    context: Dict[str, Any] = field(default_factory=dict)
    tools: List[str] = field(default_factory=list)
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parent_id: Optional[str] = None


@dataclass
class SubagentResult:
    agent_id: str
    role: str
    output: Any
    success: bool
    error: Optional[str] = None


class SubagentSpawner:
    """Manages creation and lifecycle of subagents.

    Subagents are spawned with isolated context windows to prevent
    context overflow in long-running workflows. Each subagent receives
    only the context relevant to its assigned todo item.

    Usage::

        spawner = SubagentSpawner(run_fn=my_agent_runner)
        spec = SubagentSpec(role="researcher", goal="Summarise paper X")
        result = spawner.spawn(spec)
    """

    def __init__(self, run_fn: Optional[Callable[[SubagentSpec], Any]] = None) -> None:
        """
        Args:
            run_fn: Callable that accepts a SubagentSpec and returns a result.
                    Defaults to a no-op stub for testing.
        """
        self._run_fn = run_fn or self._stub_run
        self._registry: Dict[str, SubagentSpec] = {}

    @staticmethod
    def _stub_run(spec: SubagentSpec) -> Any:
        return f"[stub] Completed goal: {spec.goal}"

    def spawn(self, spec: SubagentSpec) -> SubagentResult:
        """Spawn a subagent and return its result.

        Args:
            spec: SubagentSpec describing the subagent's role and goal.

        Returns:
            SubagentResult with output or error information.
        """
        self._registry[spec.agent_id] = spec
        try:
            output = self._run_fn(spec)
            return SubagentResult(
                agent_id=spec.agent_id,
                role=spec.role,
                output=output,
                success=True,
            )
        except Exception as exc:
            return SubagentResult(
                agent_id=spec.agent_id,
                role=spec.role,
                output=None,
                success=False,
                error=str(exc),
            )

    def spawn_many(self, specs: List[SubagentSpec]) -> List[SubagentResult]:
        """Spawn multiple subagents sequentially and collect results."""
        return [self.spawn(spec) for spec in specs]

    def get_spec(self, agent_id: str) -> Optional[SubagentSpec]:
        return self._registry.get(agent_id)
