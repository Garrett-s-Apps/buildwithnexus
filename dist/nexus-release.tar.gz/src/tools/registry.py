"""
Tool registry for NEXUS agents.

Maps agent roles to their permitted tool sets. Each role gets a curated
subset of tools to enforce least-privilege access to system capabilities.
"""

from collections.abc import Callable

from .filesystem import list_directory, read_file, write_file

_filesystem_all: list[Callable] = [read_file, write_file, list_directory]
_filesystem_read: list[Callable] = [read_file]
_filesystem_rw: list[Callable] = [read_file, write_file]


class ToolRegistry:
    """Maps agent roles to their permitted tool sets."""

    def __init__(self) -> None:
        self._tools: dict[str, list[Callable]] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        self._tools["engineer"] = _filesystem_all.copy()
        self._tools["researcher"] = _filesystem_read.copy()
        self._tools["planner"] = []
        self._tools["reviewer"] = _filesystem_read.copy()
        self._tools["qa_engineer"] = _filesystem_rw.copy()
        self._tools["devops"] = _filesystem_all.copy()
        self._tools["designer"] = _filesystem_read.copy()
        self._tools["ceo"] = _filesystem_all.copy()

    def register(self, role: str, tools: list[Callable]) -> None:
        """Register (or overwrite) the tool set for a role."""
        self._tools[role] = tools

    def get_tools_for_role(self, role: str) -> list[Callable]:
        """Return the tools available to the given role (empty list if unknown)."""
        return self._tools.get(role, [])

    def get_all_roles(self) -> list[str]:
        """Return all registered role names."""
        return list(self._tools.keys())


# Module-level singleton — import and call rather than constructing per-agent.
_global_registry = ToolRegistry()


def get_tool_registry() -> ToolRegistry:
    """Return the global ToolRegistry singleton."""
    return _global_registry


def get_tools_for_role(role: str) -> list[Callable]:
    """Convenience wrapper: look up tools for a role on the global registry."""
    return _global_registry.get_tools_for_role(role)
