from datetime import datetime
from typing import List, Optional
import uuid

from ..runtime.state import Todo


class TodoManager:
    def __init__(self):
        self.todos: dict[str, Todo] = {}

    def create(self, title: str, description: str) -> str:
        """Create a new todo and return its id."""
        todo_id = str(uuid.uuid4())
        self.todos[todo_id] = {
            "id": todo_id,
            "title": title,
            "description": description,
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
            "completed_at": None,
        }
        return todo_id

    def get(self, todo_id: str) -> Optional[Todo]:
        return self.todos.get(todo_id)

    def list_by_status(self, status: str) -> List[Todo]:
        return [t for t in self.todos.values() if t["status"] == status]

    def update_status(self, todo_id: str, new_status: str) -> Todo:
        if todo_id not in self.todos:
            raise KeyError(f"Todo {todo_id} not found")
        self.todos[todo_id]["status"] = new_status
        if new_status == "done":
            self.todos[todo_id]["completed_at"] = datetime.utcnow().isoformat()
        return self.todos[todo_id]

    def to_list(self) -> List[Todo]:
        return list(self.todos.values())
